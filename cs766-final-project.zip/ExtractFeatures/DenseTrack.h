#ifndef DenseTrack_h
#define DenseTrack_h

int DenseTrack(int argc, char** argv);

#endif
